﻿
namespace WUL
{
    partial class TestEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtTest1_1 = new WUL.Ctrls.GTextBox();
            this.pnlMain1 = new WUL.Ctrls.GPanel();
            this.pnlItem1_1 = new WUL.Ctrls.GPanel();
            this.pnlItem1_2 = new WUL.Ctrls.GPanel();
            this.txtTest1_2 = new WUL.Ctrls.GTextBox();
            this.pnlMain2 = new WUL.Ctrls.GPanel();
            this.pnlItem2_1 = new WUL.Ctrls.GPanel();
            this.txtTest2_1 = new WUL.Ctrls.GTextBox();
            this.pnlMain3 = new WUL.Ctrls.GPanel();
            this.pnlItem3_1 = new WUL.Ctrls.GPanel();
            this.txtTest3_1 = new WUL.Ctrls.GTextBox();
            this.txtNew = new WUL.Ctrls.GTextBox();
            this.pnlMain1.SuspendLayout();
            this.pnlItem1_1.SuspendLayout();
            this.pnlItem1_2.SuspendLayout();
            this.pnlMain2.SuspendLayout();
            this.pnlItem2_1.SuspendLayout();
            this.pnlMain3.SuspendLayout();
            this.pnlItem3_1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtTest1_1
            // 
            this.txtTest1_1.AutoHScroll = false;
            this.txtTest1_1.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtTest1_1.Location = new System.Drawing.Point(5, 5);
            this.txtTest1_1.MinimumSize = new System.Drawing.Size(0, 19);
            this.txtTest1_1.Multiline = true;
            this.txtTest1_1.Name = "txtTest1_1";
            this.txtTest1_1.Size = new System.Drawing.Size(269, 19);
            // 
            // pnlMain1
            // 
            this.pnlMain1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlMain1.AutoScroll = true;
            this.pnlMain1.BackColor = System.Drawing.Color.Blue;
            this.pnlMain1.FloatScrollBar = true;
            this.pnlMain1.GControls.Add(this.pnlItem1_1);
            this.pnlMain1.GControls.Add(this.pnlItem1_2);
            this.pnlMain1.Location = new System.Drawing.Point(12, 12);
            this.pnlMain1.Name = "pnlMain1";
            this.pnlMain1.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.pnlMain1.Size = new System.Drawing.Size(298, 137);
            // 
            // pnlItem1_1
            // 
            this.pnlItem1_1.AutoSize = true;
            this.pnlItem1_1.AutoSizeMode = ((WUL.Ctrls.GAutoSizeMode)((WUL.Ctrls.GAutoSizeMode.ShrinkHeight | WUL.Ctrls.GAutoSizeMode.GrowHeight)));
            this.pnlItem1_1.BackColor = System.Drawing.Color.Red;
            this.pnlItem1_1.BorderColor = System.Drawing.Color.Red;
            this.pnlItem1_1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlItem1_1.GControls.Add(this.txtTest1_1);
            this.pnlItem1_1.Location = new System.Drawing.Point(0, 10);
            this.pnlItem1_1.Name = "pnlItem1_1";
            this.pnlItem1_1.Padding = new System.Windows.Forms.Padding(5, 5, 24, 5);
            this.pnlItem1_1.Size = new System.Drawing.Size(300, 29);
            // 
            // pnlItem1_2
            // 
            this.pnlItem1_2.AutoSize = true;
            this.pnlItem1_2.AutoSizeMode = ((WUL.Ctrls.GAutoSizeMode)((WUL.Ctrls.GAutoSizeMode.ShrinkHeight | WUL.Ctrls.GAutoSizeMode.GrowHeight)));
            this.pnlItem1_2.BackColor = System.Drawing.Color.Lime;
            this.pnlItem1_2.BorderColor = System.Drawing.Color.Red;
            this.pnlItem1_2.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlItem1_2.GControls.Add(this.txtTest1_2);
            this.pnlItem1_2.Location = new System.Drawing.Point(0, 39);
            this.pnlItem1_2.Name = "pnlItem1_2";
            this.pnlItem1_2.Padding = new System.Windows.Forms.Padding(5, 5, 24, 5);
            this.pnlItem1_2.Size = new System.Drawing.Size(300, 29);
            // 
            // txtTest1_2
            // 
            this.txtTest1_2.AutoHScroll = false;
            this.txtTest1_2.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtTest1_2.Location = new System.Drawing.Point(5, 5);
            this.txtTest1_2.MinimumSize = new System.Drawing.Size(0, 19);
            this.txtTest1_2.Multiline = true;
            this.txtTest1_2.Name = "txtTest1_2";
            this.txtTest1_2.Size = new System.Drawing.Size(269, 19);
            // 
            // pnlMain2
            // 
            this.pnlMain2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlMain2.AutoScroll = true;
            this.pnlMain2.BackColor = System.Drawing.Color.Blue;
            this.pnlMain2.FloatScrollBar = true;
            this.pnlMain2.GControls.Add(this.pnlItem2_1);
            this.pnlMain2.Location = new System.Drawing.Point(12, 196);
            this.pnlMain2.Name = "pnlMain2";
            this.pnlMain2.Size = new System.Drawing.Size(298, 137);
            // 
            // pnlItem2_1
            // 
            this.pnlItem2_1.AutoSize = true;
            this.pnlItem2_1.AutoSizeMode = ((WUL.Ctrls.GAutoSizeMode)((WUL.Ctrls.GAutoSizeMode.ShrinkHeight | WUL.Ctrls.GAutoSizeMode.GrowHeight)));
            this.pnlItem2_1.BackColor = System.Drawing.Color.Red;
            this.pnlItem2_1.BorderColor = System.Drawing.Color.Red;
            this.pnlItem2_1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlItem2_1.GControls.Add(this.txtTest2_1);
            this.pnlItem2_1.Location = new System.Drawing.Point(-252, 0);
            this.pnlItem2_1.MinimumSize = new System.Drawing.Size(400, 0);
            this.pnlItem2_1.Name = "pnlItem2_1";
            this.pnlItem2_1.Padding = new System.Windows.Forms.Padding(10, 10, 24, 30);
            this.pnlItem2_1.Size = new System.Drawing.Size(400, 59);
            // 
            // txtTest2_1
            // 
            this.txtTest2_1.AutoHScroll = false;
            this.txtTest2_1.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtTest2_1.Location = new System.Drawing.Point(10, 10);
            this.txtTest2_1.MinimumSize = new System.Drawing.Size(0, 19);
            this.txtTest2_1.Multiline = true;
            this.txtTest2_1.Name = "txtTest2_1";
            this.txtTest2_1.Size = new System.Drawing.Size(366, 19);
            // 
            // pnlMain3
            // 
            this.pnlMain3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlMain3.AutoScroll = true;
            this.pnlMain3.BackColor = System.Drawing.Color.Blue;
            this.pnlMain3.GControls.Add(this.pnlItem3_1);
            this.pnlMain3.Location = new System.Drawing.Point(12, 383);
            this.pnlMain3.Name = "pnlMain3";
            this.pnlMain3.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.pnlMain3.Size = new System.Drawing.Size(298, 137);
            // 
            // pnlItem3_1
            // 
            this.pnlItem3_1.AutoSize = true;
            this.pnlItem3_1.AutoSizeMode = ((WUL.Ctrls.GAutoSizeMode)((WUL.Ctrls.GAutoSizeMode.ShrinkHeight | WUL.Ctrls.GAutoSizeMode.GrowHeight)));
            this.pnlItem3_1.BackColor = System.Drawing.Color.Red;
            this.pnlItem3_1.BorderColor = System.Drawing.Color.Red;
            this.pnlItem3_1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlItem3_1.GControls.Add(this.txtTest3_1);
            this.pnlItem3_1.Location = new System.Drawing.Point(0, 10);
            this.pnlItem3_1.Name = "pnlItem3_1";
            this.pnlItem3_1.Size = new System.Drawing.Size(300, 19);
            // 
            // txtTest3_1
            // 
            this.txtTest3_1.AutoHScroll = false;
            this.txtTest3_1.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtTest3_1.Location = new System.Drawing.Point(0, 0);
            this.txtTest3_1.MinimumSize = new System.Drawing.Size(0, 19);
            this.txtTest3_1.Multiline = true;
            this.txtTest3_1.Name = "txtTest3_1";
            this.txtTest3_1.Size = new System.Drawing.Size(298, 19);
            // 
            // txtNew
            // 
            this.txtNew.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNew.AutoSize = false;
            this.txtNew.Location = new System.Drawing.Point(12, 540);
            this.txtNew.Multiline = true;
            this.txtNew.Name = "txtNew";
            this.txtNew.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Both;
            this.txtNew.Size = new System.Drawing.Size(298, 72);
            // 
            // TestEditForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(331, 645);
            this.GControls.Add(this.pnlMain1);
            this.GControls.Add(this.pnlMain2);
            this.GControls.Add(this.pnlMain3);
            this.GControls.Add(this.txtNew);
            this.Name = "TestEditForm";
            this.Text = "TestEditForm";
            this.pnlMain1.ResumeLayout(false);
            this.pnlMain1.PerformLayout();
            this.pnlItem1_1.ResumeLayout(false);
            this.pnlItem1_1.PerformLayout();
            this.pnlItem1_2.ResumeLayout(false);
            this.pnlItem1_2.PerformLayout();
            this.pnlMain2.ResumeLayout(false);
            this.pnlMain2.PerformLayout();
            this.pnlItem2_1.ResumeLayout(false);
            this.pnlItem2_1.PerformLayout();
            this.pnlMain3.ResumeLayout(false);
            this.pnlMain3.PerformLayout();
            this.pnlItem3_1.ResumeLayout(false);
            this.pnlItem3_1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private WUL.Ctrls.GTextBox txtTest1_1;
        private WUL.Ctrls.GPanel pnlMain1;
        private WUL.Ctrls.GPanel pnlItem1_1;
        private WUL.Ctrls.GPanel pnlMain2;
        private WUL.Ctrls.GPanel pnlItem2_1;
        private WUL.Ctrls.GTextBox txtTest2_1;
        private WUL.Ctrls.GPanel pnlItem1_2;
        private WUL.Ctrls.GTextBox txtTest1_2;
        private WUL.Ctrls.GPanel pnlMain3;
        private WUL.Ctrls.GPanel pnlItem3_1;
        private WUL.Ctrls.GTextBox txtTest3_1;
        private WUL.Ctrls.GTextBox txtNew;
    }
}

