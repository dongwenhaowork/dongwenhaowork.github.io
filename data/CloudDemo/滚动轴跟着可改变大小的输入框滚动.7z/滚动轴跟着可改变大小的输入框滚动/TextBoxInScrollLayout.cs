﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using WUL.Ctrls;
using System.Windows.Forms;

namespace WUL.Ctrls
{
    /// <summary>
    /// 如果有可以长高的（或者长宽的）输入框，直接（或间接）位于具有滚动条的容器中。
    /// 可以使用本类对象来避免，输入时滚动轴没有跟着光标滚动，输入的文本看不到的问题。
    /// </summary>
    public class TextBoxInScrollLayout
    {
        private GTextBox textBox;

        /// <summary>
        /// 直接或间接包含输入框 <see cref="textBox"/> 的具有滚动条的容器。
        /// </summary>
        private GScrollableControl scrollableControl;

        /// <summary>
        /// 输入框光标所在位置的下标。
        /// </summary>
        private int oldSelectionStart;

        /// <summary>
        /// 相对于输入框自身的位置，输入框光标所在位置。
        /// </summary>
        private Point oldSelectionPosition;

        /// <summary>
        /// 输入框是否处于持续按下的状态。支持长按移动光标的键。
        /// </summary>
        private bool isOnKeyDown;

        /// <summary>
        /// <para>
        /// 如果有可以长高的（或者长宽的）输入框，直接（或间接）位于具有滚动条的容器中。
        /// 可以使用本对象来避免，输入时滚动轴没有跟着光标滚动，输入的文本看不到的问题。
        /// </para>
        /// <para>
        /// 如果没有指定具有滚动条的容器，
        /// 就会迭代 <paramref name="textBox"/> 的直接的（或间接的）父控件，
        /// 直到找到一个具有滚动条的容器。
        /// 即 IGControlContainer.AutoScroll 为 true 的直接的（或间接的）父控件。
        /// </para>
        /// </summary>
        /// <param name="textBox"></param>
        /// <param name="enableHorizontal">是否可以调整水平方向的滚动条。</param>
        /// <param name="enableVertical">是否可以调整垂直方向的滚动条。</param>
        public TextBoxInScrollLayout(GTextBox textBox, bool enableHorizontal, bool enableVertical)
        {
            textBox.Disposed += TextBox_Disposed;
            textBox.ParentChanged += TextBox_ParentChanged;
            textBox.GotFocus += TextBox_GotFocus;
            textBox.KeyUp += TextBox_KeyUp;
            textBox.KeyDown += TextBox_KeyDown;
            textBox.TextChanged += TextBox_TextChanged;

            this.textBox = textBox;
            this.EnableHorizontal = enableHorizontal;
            this.EnableVertical = enableVertical;
        }

        /// <summary>
        /// 当输入框失去焦点后，是否依旧可以调整具有滚动条的容器的滚动条。
        /// </summary>
        public bool EnableWhenNotFocused { get; set; }

        /// <summary>
        /// 是否可以调整具有滚动条的容器的水平方向的滚动条。
        /// </summary>
        public bool EnableHorizontal { get; set; }

        /// <summary>
        /// 是否可以调整具有滚动条的容器的垂直方向的滚动条。
        /// </summary>
        public bool EnableVertical { get; set; }

        private void TextBox_Disposed(object sender, EventArgs e)
        {
            textBox.Disposed -= TextBox_Disposed;
            textBox.ParentChanged -= TextBox_ParentChanged;
            textBox.GotFocus -= TextBox_GotFocus;
            textBox.KeyUp -= TextBox_KeyUp;
            textBox.KeyDown -= TextBox_KeyDown;
            textBox.TextChanged -= TextBox_TextChanged;

            textBox = null;
            scrollableControl = null;
        }

        private void TextBox_ParentChanged(object sender, EventArgs e)
        {
            this.scrollableControl = null;
        }

        private void InitScrollableControl()
        {
            if (scrollableControl == null)
            {
                IGControlContainer parent = textBox.Parent;
                while (parent != null && !parent.AutoScroll)
                {
                    parent = parent.Parent as IGControlContainer;
                }

                if (parent != null && parent is GScrollableControl)
                {
                    scrollableControl = parent as GScrollableControl;
                }
            }
        }

        private void TextBox_GotFocus(object sender, EventArgs e)
        {
            InitScrollableControl();

            // 初始化旧状态。
            int selectionStart = textBox.SelectionStart;
            if (selectionStart != oldSelectionStart)
            {
                oldSelectionStart = selectionStart;
                // oldSelectionPosition = textBox.GetPositionFromCharIndex(selectionStart);
                oldSelectionPosition = textBox.CaretBounds.Location;
            }
        }

        private void TextBox_SelectionChanged(object sender, EventArgs e)
        {
            ChangeScrollableControlScroll();
        }

        private void TextBox_TextChanged(object sender, EventArgs e)
        {
            ChangeScrollableControlScroll();
        }

        private void TextBox_KeyDown(object sender, KeyEventArgs e)
        {
            // 如果输入框处于持续按下的状态。支持长按移动光标的键。
            if (isOnKeyDown)
            {
                switch (e.KeyCode)
                {
                    case Keys.Up:
                    case Keys.Down:
                    case Keys.Left:
                    case Keys.Right:
                        ChangeScrollableControlScroll();
                        break;
                }
            }
            else
            {
                isOnKeyDown = true;
            }
        }

        private void TextBox_KeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            isOnKeyDown = false;

            switch (e.KeyCode)
            {
                case Keys.Up:
                case Keys.Down:
                case Keys.Left:
                case Keys.Right:
                    ChangeScrollableControlScroll();
                    break;
            }
        }

        /// <summary>
        /// 调整具有滚动条的容器的滚动条的位置。
        /// </summary>
        private void ChangeScrollableControlScroll()
        {
            if (scrollableControl != null && (EnableVertical || EnableHorizontal) && (EnableWhenNotFocused || textBox.FocusedCore))
            {
                int selectionStart = textBox.SelectionStart;
                // 测试 System.Diagnostics.Debug.WriteLine($"Selection Start: {oldSelectionStart} > {selectionStart}  Length {textBox.Text.Length}");

                if (selectionStart != oldSelectionStart)
                {
                    //Point selectionPosition = textBox.GetPositionFromCharIndex(selectionStart);
                    Point selectionPosition = textBox.CaretBounds.Location;
                    // 测试 System.Diagnostics.Debug.WriteLine($"Selection Position: {oldSelectionPosition} > {selectionPosition}");

                    // 使用 IsReturnEnd(selectionStart) ，
                    // 避免使用键盘，切换倒数第1行（倒数第1行只有换行符）与倒数第2行间时，selectionPosition.Y 不改变的问题。
                    if ((EnableVertical && (selectionPosition.Y != oldSelectionPosition.Y || IsReturnEnd(selectionStart))) ||
                        (EnableHorizontal && (selectionPosition.X != oldSelectionPosition.X)))
                    {
                        Point newVisibleLeftTop;
                        Point newVisibleRightBottom;
                        GetNewVisiblePoint(selectionStart, selectionPosition, out newVisibleLeftTop, out newVisibleRightBottom);

                        Rectangle visibleClientRectangle = GetVisibleClientRectangle();

                        int dx = 0;
                        if (EnableHorizontal)
                        {
                            // 如果不可见的内容在左边。
                            if (newVisibleLeftTop.X < 0)
                            {
                                dx = newVisibleLeftTop.X;
                            }
                            // 如果不可见的内容在右边。
                            else if (newVisibleRightBottom.X > visibleClientRectangle.Width)
                            {
                                dx = newVisibleRightBottom.X - visibleClientRectangle.Width;

                            }
                        }

                        int dy = 0;
                        if (EnableVertical)
                        {
                            // 如果不可见的内容在上面。
                            if (newVisibleLeftTop.Y < 0)
                            {
                                dy = newVisibleLeftTop.Y;
                            }
                            // 如果不可见的内容在下面。
                            else if (newVisibleRightBottom.Y > visibleClientRectangle.Height)
                            {
                                dy = newVisibleRightBottom.Y - visibleClientRectangle.Height;
                            }
                        }

                        if (dx != 0 || dy != 0)
                        {
                            scrollableControl.ScrollBy(dx, dy);
                        }
                    }
                    oldSelectionStart = selectionStart;
                    oldSelectionPosition = selectionPosition;
                }
            }
        }

        /// <summary>
        /// 判断选中的是不是为换行的结尾。
        /// </summary>
        /// <param name="selectionStart"></param>
        /// <returns></returns>
        private bool IsReturnEnd(int selectionStart)
        {
            string text = textBox.Text;
            int length = text.Length;
            bool isEndAndReturn = false;
            if (length > 0)
            {
                char end = text[length - 1];
                isEndAndReturn = selectionStart >= length && (end == '\r' || end == '\n');
            }
            return isEndAndReturn;
        }

        /// <summary>
        /// 计算出输入框控件的新的可见部分的左上方、右下角相对于可以滚动的控件的坐标。
        /// </summary>
        /// <param name="selectionStart"></param>
        /// <param name="selectionPosition"></param>
        /// <param name="newVisibleLeftTop"></param>
        /// <param name="newVisibleRightBottom"></param>
        private void GetNewVisiblePoint(int selectionStart, Point selectionPosition,
            out Point newVisibleLeftTop, out Point newVisibleRightBottom)
        {
            Point selectionLeftTop = selectionPosition;
            Point selectionRightBottom = Point.Empty;
            if (EnableHorizontal)
            {
                // 如果可以滚动水平方向的滚动条，使用 Font.Height 避免光标和光标右侧的内容不可见的问题。
                selectionRightBottom.X = Math.Min(selectionLeftTop.X + textBox.Font.Height, textBox.Width);

                // 如果可以滚动水平方向的滚动条，处理换行前、后字符不显示的问题。
                if (selectionPosition.Y != oldSelectionPosition.Y)
                {
                    int changeStart = selectionStart - oldSelectionStart;
                    if (changeStart == 1)
                    {
                        // 处理上一行末尾，通过添加可见字符（不包括通过换行）移动到下一行开始，
                        // 光标位于下一行第一个字符后面的问题。
                        selectionLeftTop.X = 0;
                    }
                    else if (changeStart == -1)
                    {
                        // 处理下一行开始返回到上一行末尾，光标位于上一行最后一个字符前面的问题。
                        selectionRightBottom.X = Math.Min(textBox.Width, selectionLeftTop.X + textBox.Width / 2);
                    }
                }
            }

            if (EnableVertical)
            {
                if (selectionStart >= textBox.Text.Length)
                {
                    // 不知道为何，最后一个空行，在很多情况下，只显示半行光标。
                    // 如果可以滚动垂直方向的滚动条，输入框下移到最后一行，处理输入框最下方的内容不可见的问题。
                    selectionRightBottom.Y = textBox.Height;
                }
                else
                {
                    // 如果可以滚动垂直方向的滚动条，处理光标所在行下方的内容不可见的问题。
                    selectionRightBottom.Y = selectionLeftTop.Y + textBox.Font.Height;
                }

                if (selectionPosition.Y < oldSelectionPosition.Y)
                {
                    // 如果可以滚动垂直方向的滚动条，输入框回退到第一行，处理输入框最上方的内容不可见的问题。
                    if (selectionLeftTop.Y <= textBox.Padding.Top + textBox.Font.Height)
                    {
                        selectionLeftTop.Y = 0;
                    }
                }
                else if (selectionPosition.Y > oldSelectionPosition.Y)
                {
                    // 如果可以滚动垂直方向的滚动条，输入框下移到最后一行，处理输入框最下方的内容不可见的问题。
                    if (selectionRightBottom.Y >= textBox.Height - textBox.Padding.Bottom - textBox.Font.Height)
                    {
                        selectionRightBottom.Y = textBox.Height;
                    }
                }
            }

            // 处理光标参考系不同的问题。
            // 控件中光标的位置相对于可滚动控件的位置，该位置已经减去滚动条的偏移。
            newVisibleLeftTop = textBox.PointToControl(scrollableControl, selectionLeftTop);
            newVisibleRightBottom = textBox.PointToControl(scrollableControl, selectionRightBottom);
        }

        /// <summary>
        /// 重新计算具有滚动条的容器的可见区域大小，避免内容被滚动条遮挡。
        /// </summary>
        private Rectangle GetVisibleClientRectangle()
        {
            Rectangle scrollableControlClient = scrollableControl.ClientRectangle;

            // 重新计算可见区域大小，避免内容被滚动条遮挡。
            Size scrollBar = Size.Empty;
            if (EnableVertical && scrollableControl.VScroll)
            {
                scrollBar.Width = scrollableControl.VerticalScroll.Width;
            }
            if (EnableHorizontal && scrollableControl.HScroll)
            {
                scrollBar.Height = scrollableControl.HorizontalScroll.Height;
            }
            if (scrollBar.Width != 0 || scrollBar.Height != 0)
            {
                scrollableControlClient.Size = scrollableControlClient.Size - scrollBar;
            }

            return scrollableControlClient;
        }
    }
}