﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WUL.Ctrls;
using WUL.Forms;
using WUL.Localization;

namespace WUL
{
    public partial class TestEditForm : WUL.Ctrls.GHostForm
    {
        public TestEditForm()
        {
            InitializeComponent();

            if (!DesignMode)
            {
                new TextBoxInScrollLayout(txtTest1_1, false, true);
                new TextBoxInScrollLayout(txtTest1_2, false, true);
                new TextBoxInScrollLayout(txtTest2_1, true, true);
                new TextBoxInScrollLayout(txtTest3_1, false, true);
            }
        }
    }
}
